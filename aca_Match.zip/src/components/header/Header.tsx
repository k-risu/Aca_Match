import React from "react";

const Header = () => {
  return <div>Header</div>;
};

export default Header;
