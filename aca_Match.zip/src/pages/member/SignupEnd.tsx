import React from "react";

function SignupEnd() {
  return <div>SignupEnd</div>;
}

export default SignupEnd;
