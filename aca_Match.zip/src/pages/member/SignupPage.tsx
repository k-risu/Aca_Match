import React from "react";

function SignupPage() {
  return <div>SignupPage</div>;
}

export default SignupPage;
