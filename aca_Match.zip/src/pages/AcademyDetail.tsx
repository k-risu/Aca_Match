import React from "react";

function AcademyDetail() {
  return <div>AcademyDetail</div>;
}

export default AcademyDetail;
