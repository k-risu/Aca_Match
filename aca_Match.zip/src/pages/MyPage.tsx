import React from "react";

function MyPage() {
  return <div>MyPage</div>;
}

export default MyPage;
