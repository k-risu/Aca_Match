import React from "react";

function AcademySearch() {
  return <div>AcademySearch</div>;
}

export default AcademySearch;
